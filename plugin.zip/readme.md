# TestCode

**TestCode** is a plugin for testing Acode at runtime. It is useful for Acode contributors and plugin developers who want to ensure that their changes haven’t broken existing functionality.

To run the tests, press **Ctrl + T**.

Contributions are welcome! Feel free to add new tests to improve the overall effectiveness of the plugin.

Repository:
https://github.com/RohitKushvaha01/TestCode